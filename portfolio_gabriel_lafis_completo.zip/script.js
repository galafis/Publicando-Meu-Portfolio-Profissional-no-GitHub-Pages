// Script para interações futuras
// Exemplo: carregar dados dinâmicos no futuro de um JSON externo
// fetch('dados.json')
//   .then(resposta => resposta.json())
//   .then(dados => console.log(dados));